using System;

namespace XRL.UI.Framework;

[Serializable]
public class StartingLocationItem
{
	public string Blueprint;

	public int Number;
}
