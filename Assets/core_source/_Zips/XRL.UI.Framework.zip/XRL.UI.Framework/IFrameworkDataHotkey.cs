namespace XRL.UI.Framework;

public interface IFrameworkDataHotkey
{
	string Hotkey { get; set; }
}
