using System;

namespace XRL.UI.Framework;

[Serializable]
public class FrameworkDataElement
{
	public string Id;

	public string Description;
}
