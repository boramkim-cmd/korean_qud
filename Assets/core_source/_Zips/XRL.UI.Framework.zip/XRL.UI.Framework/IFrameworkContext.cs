namespace XRL.UI.Framework;

public interface IFrameworkContext
{
	NavigationContext GetNavigationContext();
}
