namespace XRL.UI.Framework;

public class HorizontalMenuScroller : HorizontalScroller
{
}
