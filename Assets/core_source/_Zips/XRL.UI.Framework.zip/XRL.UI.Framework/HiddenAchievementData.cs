namespace XRL.UI.Framework;

public class HiddenAchievementData : FrameworkDataElement
{
	public int Amount;

	public HiddenAchievementData(int Amount)
	{
		this.Amount = Amount;
	}
}
