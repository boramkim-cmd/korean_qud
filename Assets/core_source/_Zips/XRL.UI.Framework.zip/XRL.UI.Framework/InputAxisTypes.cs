namespace XRL.UI.Framework;

public enum InputAxisTypes
{
	NavigationXAxis,
	NavigationYAxis,
	NavigationPageXAxis,
	NavigationPageYAxis,
	NavigationUAxis,
	NavigationVAxis
}
