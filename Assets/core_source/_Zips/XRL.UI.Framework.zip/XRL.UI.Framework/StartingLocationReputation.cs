using System;

namespace XRL.UI.Framework;

[Serializable]
public class StartingLocationReputation
{
	public string Faction;

	public int Modifier;
}
