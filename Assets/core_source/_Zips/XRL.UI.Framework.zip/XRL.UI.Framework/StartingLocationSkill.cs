using System;

namespace XRL.UI.Framework;

[Serializable]
public class StartingLocationSkill
{
	public string Class;
}
