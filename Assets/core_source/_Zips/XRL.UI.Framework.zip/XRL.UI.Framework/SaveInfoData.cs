using Qud.API;

namespace XRL.UI.Framework;

public class SaveInfoData : FrameworkDataElement
{
	public SaveGameInfo SaveGame;
}
