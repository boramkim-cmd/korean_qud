namespace XRL.UI.Framework;

public class ScrollChildContext : ProxyNavigationContext
{
	public int index;
}
