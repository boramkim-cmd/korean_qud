namespace XRL.UI.Framework;

public interface IFrameworkControlSubcontexts
{
	void SetupContexts(ScrollChildContext context);
}
