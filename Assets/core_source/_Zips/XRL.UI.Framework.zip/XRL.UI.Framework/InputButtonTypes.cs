namespace XRL.UI.Framework;

public enum InputButtonTypes
{
	AcceptButton,
	CancelButton
}
