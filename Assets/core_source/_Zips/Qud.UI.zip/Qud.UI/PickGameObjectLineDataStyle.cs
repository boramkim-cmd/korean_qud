namespace Qud.UI;

public enum PickGameObjectLineDataStyle
{
	Interact,
	SelectSingle,
	SelectMultiple
}
