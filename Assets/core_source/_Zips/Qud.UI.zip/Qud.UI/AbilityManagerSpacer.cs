using UnityEngine;
using UnityEngine.UI;

namespace Qud.UI;

public class AbilityManagerSpacer : MonoBehaviour
{
	public Image image;
}
