namespace Qud.UI;

public enum TradeLineDataStyle
{
	Interact,
	SelectSingle,
	SelectMultiple
}
