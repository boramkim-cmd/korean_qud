namespace Qud.UI;

public enum TradeLineDataType
{
	Item,
	Category
}
