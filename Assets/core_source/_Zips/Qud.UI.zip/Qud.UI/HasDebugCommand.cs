using System;

namespace Qud.UI;

[AttributeUsage(AttributeTargets.Class)]
public class HasDebugCommand : Attribute
{
}
