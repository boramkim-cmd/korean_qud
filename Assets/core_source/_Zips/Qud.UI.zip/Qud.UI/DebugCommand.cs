using System;

namespace Qud.UI;

[AttributeUsage(AttributeTargets.Method)]
public class DebugCommand : Attribute
{
}
