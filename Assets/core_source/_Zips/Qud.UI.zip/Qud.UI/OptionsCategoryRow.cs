namespace Qud.UI;

public class OptionsCategoryRow : OptionsDataRow
{
	public bool categoryExpanded;
}
