namespace Qud.UI;

public enum PickGameObjectLineDataType
{
	Item,
	Category
}
