namespace XRL.UI;

public class StepEntry
{
	public string Text = "";

	public string StepText = "";

	public int MaxSteps = 100;

	public int CurrentStep = -1;
}
