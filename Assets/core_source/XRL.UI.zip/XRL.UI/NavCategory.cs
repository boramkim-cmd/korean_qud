using System.Collections.Generic;

namespace XRL.UI;

public class NavCategory
{
	public string ID;

	public List<string> Layers;
}
