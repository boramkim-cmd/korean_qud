namespace XRL.UI;

public class BannerText
{
	public BannerTextType Type;

	public TextBlock Block;

	public int Time;

	public int x;

	public int y;

	public int Life = 150;

	public bool Complete;
}
