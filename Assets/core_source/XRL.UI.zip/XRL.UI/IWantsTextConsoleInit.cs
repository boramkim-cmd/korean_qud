using ConsoleLib.Console;

namespace XRL.UI;

public interface IWantsTextConsoleInit
{
	void Init(TextConsole console, ScreenBuffer buffer);
}
