namespace XRL.UI;

public enum ScreenReturn
{
	Next,
	Previous,
	Exit
}
