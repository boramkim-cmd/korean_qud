namespace XRL.UI;

public enum BannerTextType
{
	GoldenText
}
