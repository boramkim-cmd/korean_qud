namespace XRL.UI;

public enum DialogResult
{
	Yes,
	No,
	OK,
	Cancel
}
