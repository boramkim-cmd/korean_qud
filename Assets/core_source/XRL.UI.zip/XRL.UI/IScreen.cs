using XRL.World;

namespace XRL.UI;

public interface IScreen
{
	ScreenReturn Show(GameObject GO);
}
