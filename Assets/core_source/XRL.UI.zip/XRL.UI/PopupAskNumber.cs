namespace XRL.UI;

[UIView("Popup:AskNumber", false, true, false, "Menu", null, false, 0, false)]
public class PopupAskNumber
{
}
