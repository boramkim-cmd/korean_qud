using ConsoleLib.Console;

namespace XRL.UI;

public class BaseScreen
{
	public void RenderBottomBar(ScreenBuffer sb, string LeftScreen, string Right)
	{
	}
}
