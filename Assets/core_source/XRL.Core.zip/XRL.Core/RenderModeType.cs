namespace XRL.Core;

public enum RenderModeType
{
	Text,
	Tiles
}
